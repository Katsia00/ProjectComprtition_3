CREATE DATABASE IF NOT EXISTS projectcompetition;

ALTER DATABASE projectcompetition
  DEFAULT CHARACTER SET utf8
  DEFAULT COLLATE utf8_general_ci;

CREATE TABLE IF NOT EXISTS expertMarkTypes (
  id INT(4) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80),
  INDEX(name)
) engine=InnoDB;

CREATE TABLE IF NOT EXISTS users (
  id INT(4) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(30),
  last_name VARCHAR(30),
  login VARCHAR(50),
  password VARCHAR(80),
  INDEX(login)
) engine=InnoDB;

CREATE TABLE IF NOT EXISTS projects (
  id INT(4) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(30),
  expertMarkType_id INT(4) UNSIGNED NOT NULL,
  user_id INT(4) UNSIGNED NOT NULL,
  INDEX(name),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (expertMarkType_id) REFERENCES expertMarkTypes(id)
) engine=InnoDB;


