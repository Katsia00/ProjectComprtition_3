INSERT IGNORE INTO expertMarkTypes VALUES (1, 'E - Poor');
INSERT IGNORE INTO expertMarkTypes VALUES (2, 'D - Bad');
INSERT IGNORE INTO expertMarkTypes VALUES (3, 'C - Satisfactory');
INSERT IGNORE INTO expertMarkTypes VALUES (4, 'B - Good');
INSERT IGNORE INTO expertMarkTypes VALUES (5, 'A - Excellent');

INSERT IGNORE INTO users VALUES (1, 'admin', 'admin', 'admin', 'admin');
INSERT IGNORE INTO users VALUES (2, 'Betty', 'Davis', 'Betty', '6085551749');
INSERT IGNORE INTO users VALUES (3, 'Eduardo', 'Rodriquez', 'Eduardo', '6085558763');
INSERT IGNORE INTO users VALUES (4, 'Harold', 'Davis', 'Harold', '6085553198');
INSERT IGNORE INTO users VALUES (5, 'Peter', 'McTavish', 'Peter', '6085552765');
INSERT IGNORE INTO users VALUES (6, 'Jean', 'Coleman', 'Jean', '6085552654');
INSERT IGNORE INTO users VALUES (7, 'Jeff', 'Black', 'Jeff', '6085555387');
INSERT IGNORE INTO users VALUES (8, 'Maria', 'Escobito', 'Maria', '6085557683');
INSERT IGNORE INTO users VALUES (9, 'David', 'Schroeder', 'David', '6085559435');
INSERT IGNORE INTO users VALUES (10, 'Carlos', 'Estaban', 'Carlos', '6085555487');

INSERT IGNORE INTO projects VALUES (1, 'Project1', 1, 1);
INSERT IGNORE INTO projects VALUES (2, 'Basil', 6, 2);
INSERT IGNORE INTO projects VALUES (3, 'Rosy', 2, 3);
INSERT IGNORE INTO projects VALUES (4, 'Jewel', 2, 3);
INSERT IGNORE INTO projects VALUES (5, 'Iggy', 3, 4);
INSERT IGNORE INTO projects VALUES (6, 'George', 4, 5);

