package org.kate.projectcompetition.web;

import org.kate.projectcompetition.model.Project;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * <code>Validator</code> for <code>Project</code> forms.
 * <p>
 * We're not using Bean Validation annotations here because 
 * it is easier to define such validation rule in Java.
 * </p>
 *
 */
public class ProjectValidator implements Validator {

    private static final String REQUIRED = "required";

    @Override
    public void validate(Object obj, Errors errors) {
        Project project = (Project) obj;
        String name = project.getName();
        // name validation
        if (!StringUtils.hasLength(name)) {
            errors.rejectValue("name", REQUIRED, REQUIRED);
        }

        // type validation
        if (project.isNew() && project.getExpertMarkType() == null) {
            errors.rejectValue("expertMarkType", REQUIRED, REQUIRED);
        }
    }

    /**
     * This Validator validates *just* Project instances
     */
    @Override
    public boolean supports(Class<?> clazz) {
        return Project.class.isAssignableFrom(clazz);
    }


}
