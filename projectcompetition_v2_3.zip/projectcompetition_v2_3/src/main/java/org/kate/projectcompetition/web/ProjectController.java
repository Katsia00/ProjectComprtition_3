package org.kate.projectcompetition.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.Collection;
import org.kate.projectcompetition.model.ProjectExpertMarkType;
import org.kate.projectcompetition.model.Project;
import org.kate.projectcompetition.model.User;
import org.kate.projectcompetition.service.CompetitionService;

@Controller
@RequestMapping("/users/{userId}")
public class ProjectController {

    private static final String VIEWS_PROJECTS_CREATE_OR_UPDATE_FORM = "projects/createOrUpdateProjectForm";
    private final CompetitionService competitionService;

    @Autowired  //Автосвязывание
    public ProjectController(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    @ModelAttribute("expertMarkType")
    public Collection<ProjectExpertMarkType> populateProjectExpertMarkTypes() {
        return this.competitionService.findProjectExpertMarkTypes();
    }

    @ModelAttribute("user")
    public User findUser(@PathVariable("userId") int userId) {
        return this.competitionService.findUserById(userId);
    }

    @InitBinder("user")
    public void initUserBinder(WebDataBinder dataBinder) {
        dataBinder.setDisallowedFields("id");
    }

    @InitBinder("project")
    public void initProjectBinder(WebDataBinder dataBinder) {
        dataBinder.setValidator(new ProjectValidator());
    }

    @GetMapping(value = "/projects/new")
    public String initCreationForm(User user, ModelMap model) {
        Project project = new Project();
        user.addProject(project);
        model.put("project", project);
        return VIEWS_PROJECTS_CREATE_OR_UPDATE_FORM;
    }

    @PostMapping(value = "/projects/new")
    public String processCreationForm(User user, @Valid Project project, BindingResult result, ModelMap model) {
        if (StringUtils.hasLength(project.getName()) && project.isNew() && user.getProject(project.getName(), true) != null){
            result.rejectValue("name", "duplicate", "already exists");
        }
        if (result.hasErrors()) {
            model.put("project", project);
            return VIEWS_PROJECTS_CREATE_OR_UPDATE_FORM;
        } else {
            user.addProject(project);
            this.competitionService.saveProject(project);
            return "redirect:/users/{userId}";
        }
    }

    @GetMapping(value = "/projects/{projectId}/edit")
    public String initUpdateForm(@PathVariable("projectId") int projectId, ModelMap model) {
        Project project = this.competitionService.findProjectById(projectId);
        model.put("project", project);
        return VIEWS_PROJECTS_CREATE_OR_UPDATE_FORM;
    }

    @PostMapping(value = "/projects/{projectId}/edit")
    public String processUpdateForm(@Valid Project project, BindingResult result, User user, ModelMap model) {
        if (result.hasErrors()) {
            model.put("project", project);
            return VIEWS_PROJECTS_CREATE_OR_UPDATE_FORM;
        } else {
            user.addProject(project);
            this.competitionService.saveProject(project);
            return "redirect:/users/{userId}";
        }
    }

}
