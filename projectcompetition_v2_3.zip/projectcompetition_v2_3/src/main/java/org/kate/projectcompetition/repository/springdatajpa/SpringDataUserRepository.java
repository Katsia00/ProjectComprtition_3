package org.kate.projectcompetition.repository.springdatajpa;

import java.util.Collection;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;
import org.kate.projectcompetition.model.User;
import org.kate.projectcompetition.repository.UserRepository;

public interface SpringDataUserRepository extends UserRepository, Repository<User, Integer>{
    
    @Query("SELECT DISTINCT user FROM User user left join fetch user.projects WHERE user.login LIKE :login%")
    @Override
    public Collection<User> findByLogin(@Param("login") String login);

    @Override
    @Query("SELECT user FROM User user left join fetch user.projects WHERE user.id =:id")
    public User findById(@Param("id") int id);
}
