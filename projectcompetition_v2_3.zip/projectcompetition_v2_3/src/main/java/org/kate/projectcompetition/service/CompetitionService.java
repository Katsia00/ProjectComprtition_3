package org.kate.projectcompetition.service;

import java.util.Collection;
import org.kate.projectcompetition.model.ProjectExpertMarkType;
import org.kate.projectcompetition.model.Project;
import org.kate.projectcompetition.model.User;

public interface CompetitionService {
    
    Collection<ProjectExpertMarkType> findProjectExpertMarkTypes();

    User findUserById(int id);

    Project findProjectById(int id);

    void saveProject(Project project);

    void saveUser(User user);

    Collection<User> findUserByLogin(String login);

}
