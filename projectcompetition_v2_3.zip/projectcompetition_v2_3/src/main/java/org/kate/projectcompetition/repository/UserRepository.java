package org.kate.projectcompetition.repository;

import java.util.Collection;
import org.kate.projectcompetition.model.User;

public interface UserRepository {

    Collection<User> findByLogin(String login);

    User findById(int id);

    void save(User user);


}
