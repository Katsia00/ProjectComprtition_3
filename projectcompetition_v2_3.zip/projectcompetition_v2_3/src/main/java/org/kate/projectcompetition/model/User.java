package org.kate.projectcompetition.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import org.springframework.beans.support.MutableSortDefinition;
import org.springframework.beans.support.PropertyComparator;
import org.springframework.core.style.ToStringCreator;

@Entity
@Table(name = "users")
public class User extends Person{
    @Column(name = "login")
    @NotEmpty
    private String login;
     
    @Column(name = "password")
    @NotEmpty
    private String password;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "user")
    private Set<Project> projects;

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLogin() {
        return this.login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    protected Set<Project> getProjectsInternal() {
        if (this.projects == null) {
            this.projects = new HashSet<>();
        }
        return this.projects;
    }

    protected void setProjectsInternal(Set<Project> projects) {
        this.projects = projects;
    }

    public List<Project> getProjects() {
        List<Project> sortedProjects = new ArrayList<>(getProjectsInternal());
        PropertyComparator.sort(sortedProjects, new MutableSortDefinition("name", true, true));
        return Collections.unmodifiableList(sortedProjects);
    }

    public void addProject(Project project) {
        getProjectsInternal().add(project);
        project.setUser(this);
    }

    /**
     * Return the Project with the given name, 
     * or null if none found for this User.
     *
     * @param name to test
     * @return true if project name is already in use
     */
    public Project getProject(String name) {
        return getProject(name, false);
    }

    /**
     * Return the Project with the given name, 
     * or null if none found for this User.
     *
     * @param name to test
     * @return true if pet name is already in use
     */
    public Project getProject(String name, boolean ignoreNew) {
        name = name.toLowerCase();
        for (Project project : getProjectsInternal()) {
            if (!ignoreNew || !project.isNew()) {
                String compName = project.getName();
                compName = compName.toLowerCase();
                if (compName.equals(name)) {
                    return project;
                }
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return new ToStringCreator(this)
                
                .append("id", this.getId())
                .append("new", this.isNew())
                .append("lastName", this.getLastName())
                .append("firstName", this.getFirstName())
                .append("login", this.login)
                .append("password", this.password)
                .append("projects", this.projects)
                .toString();
    }
    
}
