package org.kate.projectcompetition.web;

import java.util.Collection;
import java.util.Map;
import javax.validation.Valid;
import org.kate.projectcompetition.model.User;
import org.kate.projectcompetition.service.CompetitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {

    private static final String VIEWS_USER_CREATE_OR_UPDATE_FORM = "users/createOrUpdateUserForm";
    private final CompetitionService competitionService;

    @Autowired
    public UserController(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    @InitBinder
    public void setAllowedFields(WebDataBinder dataBinder) {
        dataBinder.setDisallowedFields("id");
    }

    @GetMapping(value = "/users/new")
    public String initCreationForm(Map<String, Object> model) {
        User user = new User();
        model.put("user", user);
        return VIEWS_USER_CREATE_OR_UPDATE_FORM;
    }

    @PostMapping(value = "/users/new")
    public String processCreationForm(@Valid User user, BindingResult result) {
        if (result.hasErrors()) {
            return VIEWS_USER_CREATE_OR_UPDATE_FORM;
        } else {
            this.competitionService.saveUser(user);
            return "redirect:/users/" + user.getId();
        }
    }

    @GetMapping(value = "/users/find")
    public String initFindForm(Map<String, Object> model) {
        model.put("user", new User());
        return "users/findUsers";
    }

    @GetMapping(value = "/users")
    public String processFindForm(User user, BindingResult result, Map<String, Object> model) {

        // allow parameterless GET request for /users to return all records
        // разрешить запрос GET без параметров для /users который возвращает все записи
        if (user.getLogin()== null) {
            user.setLogin(""); // empty string signifies broadest possible search
                               // пустая строка означает максимально широкий поиск
        }

        // find users by login
        Collection<User> results = this.competitionService.findUserByLogin(user.getLogin());
        if (results.isEmpty()) {
            // no users found
            result.rejectValue("login", "notFound", "not found");
            return "users/findUsers";
        } else if (results.size() == 1) {
            // 1 user found
            user = results.iterator().next();
            return "redirect:/users/" + user.getId();
        } else {
            // multiple users found
            model.put("selections", results);
            return "users/usersList";
        }
    }

    @GetMapping(value = "/users/{userId}/edit")
    public String initUpdateUserForm(@PathVariable("userId") int userId, Model model) {
        User user = this.competitionService.findUserById(userId);
        model.addAttribute(user);
        return VIEWS_USER_CREATE_OR_UPDATE_FORM;
    }

    @PostMapping(value = "/users/{userId}/edit")
    public String processUpdateUserForm(@Valid User user, BindingResult result, @PathVariable("userId") int userId) {
        if (result.hasErrors()) {
            return VIEWS_USER_CREATE_OR_UPDATE_FORM;
        } else {
            user.setId(userId);
            this.competitionService.saveUser(user);
            return "redirect:/users/{userId}";
        }
    }

    /**
     * Custom handler for displaying an user.
     *
     * @param userId the ID of the user to display
     * @return a ModelMap with the model attributes for the view
     */
    @GetMapping("/users/{userId}")
    public ModelAndView showUser(@PathVariable("userId") int userId) {
        ModelAndView mav = new ModelAndView("users/userDetails");
        mav.addObject(this.competitionService.findUserById(userId));
        return mav;
    }

}
