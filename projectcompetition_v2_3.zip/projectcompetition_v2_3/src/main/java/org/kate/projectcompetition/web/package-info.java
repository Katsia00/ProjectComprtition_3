/**
 * The classes in this package represent Pojectcompetition's web presentation layer.
 */
package org.kate.projectcompetition.web;

