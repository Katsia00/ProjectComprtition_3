package org.kate.projectcompetition.repository.springdatajpa;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.kate.projectcompetition.model.Project;
import org.kate.projectcompetition.model.ProjectExpertMarkType;
import org.kate.projectcompetition.repository.ProjectRepository;

public interface SpringDataProjectRepository extends ProjectRepository, Repository<Project, Integer> {

    @Override
    @Query("SELECT expertMarkType FROM ProjectExpertMarkType expertMarkType ORDER BY expertMarkType.name")
    List<ProjectExpertMarkType> findProjectExpertMarkTypes();
}
