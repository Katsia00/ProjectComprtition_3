package org.kate.projectcompetition.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "expertMarkTypes")
public class ProjectExpertMarkType extends NamedEntity{
    
}
