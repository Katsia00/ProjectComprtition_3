package org.kate.projectcompetition.repository;

import java.util.List;
import org.kate.projectcompetition.model.Project;
import org.kate.projectcompetition.model.ProjectExpertMarkType;

public interface ProjectRepository {

    List<ProjectExpertMarkType> findProjectExpertMarkTypes();

    Project findById(int id);

    void save(Project project);

}
