package org.kate.projectcompetition.web;


import java.text.ParseException;
import java.util.Collection;
import java.util.Locale;
import org.kate.projectcompetition.model.ProjectExpertMarkType;
import org.kate.projectcompetition.service.CompetitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.Formatter;

/**
 * Instructs Spring MVC on how to parse and print 
 * elements of type 'ProjectExpertMarkType'. 
 * <p/>
 * Also see how the bean 'conversionService' has been declared inside /WEB-INF/mvc-core-config.xml
 *
 */
public class ProjectExpertMarkTypeFormatter implements Formatter<ProjectExpertMarkType> {

    private final CompetitionService competitionService;

    @Autowired
    public ProjectExpertMarkTypeFormatter(CompetitionService competitionService) {
        this.competitionService = competitionService;
    }

    @Override
    public String print(ProjectExpertMarkType projectExpertMarkType, Locale locale) {
        return projectExpertMarkType.getName();
    }

    @Override
    public ProjectExpertMarkType parse(String text, Locale locale) throws ParseException {
        Collection<ProjectExpertMarkType> findProjectExpertMarkTypes = this.competitionService.findProjectExpertMarkTypes();
        for (ProjectExpertMarkType type : findProjectExpertMarkTypes) {
            if (type.getName().equals(text)) {
                return type;
            }
        }
        throw new ParseException("expertMarkType not found: " + text, 0);
    }

}
