package org.kate.projectcompetition.service;

import java.util.Collection;
import org.kate.projectcompetition.model.ProjectExpertMarkType;
import org.kate.projectcompetition.model.Project;
import org.kate.projectcompetition.model.User;
import org.kate.projectcompetition.repository.ProjectRepository;
import org.kate.projectcompetition.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CompetitionServiceImpl implements CompetitionService {

    private ProjectRepository projectRepository;
    private UserRepository userRepository;

    @Autowired
    public CompetitionServiceImpl(ProjectRepository projectRepository, UserRepository userRepository) {
        this.projectRepository = projectRepository;
        this.userRepository = userRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public Collection<ProjectExpertMarkType> findProjectExpertMarkTypes() {
        return projectRepository.findProjectExpertMarkTypes();
    }

    @Override
    @Transactional(readOnly = true)
    public User findUserById(int id) {
        return userRepository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public Collection<User> findUserByLogin(String login) {
        return userRepository.findByLogin(login);
    }

    @Override
    @Transactional
    public void saveUser(User user) {
        userRepository.save(user);
    }

    @Override
    @Transactional(readOnly = true)
    public Project findProjectById(int id) {
        return projectRepository.findById(id);
    }

    @Override
    @Transactional
    public void saveProject(Project project) {
        projectRepository.save(project);
    }

}
