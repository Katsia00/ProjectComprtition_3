package org.kate.projectcompetition.model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "projects")
public class Project extends NamedEntity{

    @ManyToOne
    @JoinColumn(name = "expertMarkType_id")
    private ProjectExpertMarkType expertMarkType;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    
    public ProjectExpertMarkType getExpertMarkType() {
        return this.expertMarkType;
    }

    public void setExpertMarkType(ProjectExpertMarkType expertMarkType) {
        this.expertMarkType = expertMarkType;
    }

    public User getUser() {
        return this.user;
    }

    protected void setUser(User user) {
        this.user = user;
    }

}
